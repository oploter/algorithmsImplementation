public class HelloWorld {
    public static void main(String[] names) {
        System.out.println("Hello, World");
    }
}